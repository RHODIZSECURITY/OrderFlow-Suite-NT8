// Última actualización: 2026-04-13

#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using Serialize = NinjaTrader.NinjaScript.Serialize;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace NinjaTrader.NinjaScript.Indicators.WyckoffZen
{
	public class SupportResistance : Indicator
	{
		private Swing swing;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description = @"Soportes y resistencias automáticas basadas en Swing, pintadas como zona.";
				Name = "Support Resistance";
				Calculate = Calculate.OnBarClose;
				IsOverlay = true;
				Strength = 5;
				SupportColor = Brushes.DodgerBlue;
				ResistanceColor = Brushes.Crimson;
				ZoneTicks = 8;
				ForwardBars = 120;
				Opacity = 20;
			}
			else if (State == State.DataLoaded)
			{
				swing = Swing(Strength);
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar < Strength * 2)
				return;

			double sHigh = swing.SwingHigh[0];
			double sLow = swing.SwingLow[0];

			if (sHigh > 0)
			{
				double resTop = sHigh + (ZoneTicks * TickSize * 0.5);
				double resBot = sHigh - (ZoneTicks * TickSize * 0.5);
				Draw.Rectangle(this, "RES_ZONE_" + CurrentBar, false, 0, resTop, -ForwardBars, resBot, ResistanceColor, ResistanceColor, Opacity);
			}

			if (sLow > 0)
			{
				double supTop = sLow + (ZoneTicks * TickSize * 0.5);
				double supBot = sLow - (ZoneTicks * TickSize * 0.5);
				Draw.Rectangle(this, "SUP_ZONE_" + CurrentBar, false, 0, supTop, -ForwardBars, supBot, SupportColor, SupportColor, Opacity);
			}
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(2, 50)]
		[Display(Name = "Swing strength", GroupName = "S/R", Order = 0)]
		public int Strength { get; set; }


		[NinjaScriptProperty]
		[Range(2, 100)]
		[Display(Name = "Zone ticks", GroupName = "S/R", Order = 1)]
		public int ZoneTicks { get; set; }

		[NinjaScriptProperty]
		[Range(5, 500)]
		[Display(Name = "Forward bars", GroupName = "S/R", Order = 2)]
		public int ForwardBars { get; set; }

		[NinjaScriptProperty]
		[Range(0, 100)]
		[Display(Name = "Opacity %", GroupName = "S/R", Order = 3)]
		public int Opacity { get; set; }

		[XmlIgnore]
		[Display(Name = "Support color", GroupName = "S/R", Order = 4)]
		public Brush SupportColor { get; set; }
		[Browsable(false)]
		public string SupportColorSerializable { get { return Serialize.BrushToString(SupportColor); } set { SupportColor = Serialize.StringToBrush(value); } }

		[XmlIgnore]
		[Display(Name = "Resistance color", GroupName = "S/R", Order = 5)]
		public Brush ResistanceColor { get; set; }
		[Browsable(false)]
		public string ResistanceColorSerializable { get { return Serialize.BrushToString(ResistanceColor); } set { ResistanceColor = Serialize.StringToBrush(value); } }
		#endregion
	}
}
